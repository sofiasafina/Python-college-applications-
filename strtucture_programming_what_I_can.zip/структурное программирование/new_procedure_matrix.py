import random
from itertools import count


#--------функция создания матрицы---------------------------------------
def Matrix(n,m):
    a=[[random.randint(0,56) for i in range(m)] for _ in range(n)]
    return a
#--------процедура вывода матрицы на экран-------------------------------
def print_Matrix(name,n,m):
    for i in range(n):
        for j in range(m):
            print("{:4d}".format(name[i][j]),end=' ')
        print()
#--------функция нахождения max элемента матрицы-------------------------
def max_Matrix(name,n):
    for i in range(n):
        z = max([max(name[i]) for i in range(n)])
        return z
#-------фунцкия программы, определяющей сколько раз данное число содержится среди массивов
def counts(name,n):
    for i in range(name,n):
        u = [name.count(name[i]) for i in range(n)]
        return u

#--------функция нахождения max и min элемента матрицы-------------------------
def maximin(n):
    minv = n[0][0]
    maxv = n[0][0]
    for i in n:
        for v in i:
            if v < minv:
                minv = v
            if v > maxv:
                maxv = v
    print('min элемент матрицы: ', minv)
    print('max элемент матрицы: ', maxv)

#--------функция выполнения индивидуального задания(вывод строки из минимальных элементов матрицы каждой строки)-------------------------
def v16(n):
    me = []
    for i in n:
        mel = min(i, key=abs)
        me.append(mel)
    print('Минимальные по модулю элементы каждой строки: ', me)