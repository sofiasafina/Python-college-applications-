class TBook:
    author=""
    title=""
    count=0
# B=TBook()
# B.author="Пушкин А.С."
# B.title="Золотая рыбка"
# B.count=10
# fam=B.author.split()[0]
# print(fam)
# B.count-=1#one book left
# if B.count==0:
#     print('Этих книг больше нет')
# print(B.author, B.title+".",B.count,"шт")

Books=[]
for i in range(2):
    Books.append(TBook())
for i in range(2):
    Books[i].author = input('автор: ')#человек вводит сам
    Books[i].title = input('название: ')
    Books[i].count = input('количество: ')
for i in range(2):
    print(Books[i].author,end=';')
    print(Books[i].title,end=';')
    print(Books[i].count)
