# s=input()
#
# #подготовка
# pairs={"(":")","[":"]","{":"}"}
# stack=[]
# err=False
#
# for c in s:
#     if c in pairs:
#         stack.append(pairs[c])
#     elif c in pairs.values():
#         if not stack or c != stack.pop():
#             err=True
#             break
# if stack: err=True
#
# #вывод результата
# if not err:
#     print("Выражение правильное.")
# else: print("Выражение неправильное.")

s=''
stack=[]
while True:
    print('1) push n')
    print('2) pop')
    print('3) back')
    print('4) size')
    print('5) clear')
    print('6) exit')
    s = input('Введите командy от 1 до 6: ')
    if s=='1':
        try:
            n = int(input('Введите n: '))
            stack.append(n)
            print('OOOOKAAAAAAAY')
        except:
            print('Неверные данные')
    elif s=='2':
        try: print(stack.pop())
        except: print('error')
    elif s=='3':
        try: print(stack[-1])
        except: print('error')
    elif s=='4': print(len(stack))
    elif s=='5':
        stack.clear()
        print('OOOOKAAAAAAAY')
    elif s=='6':
        print('bye')
        break
    else:
        print('Введите правильную команду')
        pass