#общее понятие стека
# fifo=[]
# while True:
#     n=input('введите число  ')
#     if n=='0':
#         break
#     fifo.append(n)
# print(fifo)
# b=fifo.pop(0)#удаляет 1 элемент из очереди
# print(fifo)
# for i in fifo:
#     fifo.pop(0)#цикл с поэтапным удалением очереди
# print(fifo)
from inspect import stack

#задачи на стек и очередь
#1
# stack=[]
# while True:
#     n = input('введите число  ')
#     if n=='0':
#         break
#     stack.append(n)
# for i in stack:
#     print(i)
#     stack.pop()
#     print(stack)

#2
# stack=[]
# while True:
#     n = input('введите число  ')
#     if n=='0':
#         break
#     stack.append(int(n))
# print(stack)
# reverse_stack=[]
# while stack:
#     reverse_stack.append(stack.pop())
# print(reverse_stack)

#3
# def obratno(fi):
#     stack=[]
#     with open(fi,'r') as file:
#         for i in file:
#             words=i.split()
#             for w in words:
#                 stack.append(w)
#     while stack:
#         print(stack.pop())
#
# print(obratno('texty.txt'))

#4
# def chet(ochered):
#     while ochered and ochered[0]%2!=0:
#         ochered.pop(0)
#     if not ochered:
#         print('нет нечётных элементов  всписке')
#
# listt=[]
# while True:
#     n = input('введите число  ')
#     if n=='0':
#         break
#     listt.append(int(n))
# print(listt)
# ochered=list(listt)
# chet(ochered)

#5
# och1=[1,2,3,4,5,6,7,8,9,0]
# och2=[2,3,6,7,4,5,6,7,0,2]
# print(och1)
# print(och2)
# och=[]
# for i in range(len(och1)):
#     och.append(och1[i])
#     och.append(och2[i])
# print(och)

#6
# och1=[1,2,3,4,5,6,7,8,9,0]
# och2=[2,3,6,7,8,8,9,9,9,9]
# print(och1)
# print(och2)
# och=[]
# for i in range(len(och1)):
#     if och1[i]<och2[i]:
#         och.append(och1[i])
#         och.append(och2[i])
# print(och)

#7
# C=int(input('Введите число  '))
# menshe=[]
# bolshe=[]
# ost=[]
# vso=[]
# f=open('input.txt')
# for i in f:
#     if int(i)>C:
#         bolshe.append(i)
#     elif int(i)<C:
#         menshe.append(i)
#     else:
#         ost.append(i)
# while menshe:
#     print(menshe.pop(0))
# while bolshe:
#     print(bolshe.pop(0))
# while ost:
#     print(ost.pop(0))