# x=5
# y=x
# print(id(x))
# print(id(y))
# print(y is x)
#
# x=9
# print(id(x))
# x=x+9
# print(id(x))
#
# l=[2,3,4]
# print(id(l))
# l.append(6)
# print(id(l))
#
# d={1:'a',2:'b',3:'c'}
# print(d)
# print(id(d))
# d[5]='f'
# print(d)
# print(id(d))
#
# A=set('okay')
# print(A)
# print(id(A))
# A.add('b')
# print(A)
# print(id(A))

# import sys
# # sys._debugmallocstats()
#
# a={}
# b=a
# print(sys.getrefcount(a))
# del b
# print(sys.getrefcount(a))



# ЗАДАЧИ
a=[1.3,2.5,3.1]
ass={i**2 for i in a}
print(ass)

b=[i for i in range(10,21) if i%2!=0]
print(b)

tur=(3.27,5.755,7.321)
keys=[]
for i in tur:
    keys.append(i)
znac=[]
for i in tur:
    keys.append(int(i))
zv=zip(keys,znac)
print(zv)