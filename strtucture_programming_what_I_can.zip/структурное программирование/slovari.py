kays=['name','age','job']
values=['timur','38','teacher']
a=dict(zip(kays,values))
# # if 'name' in kays:
# #     print('Имя Тимура - ',kays['name'])
#
# for key in values.kays():
#     print(key)
#
# a={x:x**2+1 for x in range(5)}
# print(a)

# a={x:y for x in 'ABC' for  y in 'XYZ'}
# print(a)

# b={'A':'Z' for x in "ABC"}
# print(b)
# b={x: 1 if x in 'ACE' else 0 for x in 'ABCDEF'}
# print(b)#условие

# c={v:k for k,v in a.items()}#словарь - 1-3 строки, ключи и значения меняются местами
# print(a)

a['Рим']='Италия'
print(a)