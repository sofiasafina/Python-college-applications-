def rec_func(n):
    if n>=1:
        rec_func(n-1)
        print(n)
# rec_func(5)

def printBin(n):
    if n==0: return
    printBin(n//2)
    print(n%2,end="")

# printBin(15)

def sumDig(n):
    sum=n%10
    if n>=10:
        sum+=sumDig(n//10)
    return sum

# sumDig(123)

# задачи:

def nod(a,b):
    if b==0: return a
    else: return nod(b,a%b)

print(nod(7006652,112307574))