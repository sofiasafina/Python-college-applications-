# 1
# f=open('out.txt',encoding='utf-8')
# c=f.read()
# print('количество символов в файле: ', len(c))


# 2
# t=input('Введите текст ')
# with open('out.txt','w',encoding='utf-8') as f:
#     f.write(t)


#3
# with open('out.txt','r',encoding='utf-8') as f:
#     ws=f.read().split()
# wp=''.join(w for w in ws)
# with open('out.txt','w',encoding='utf-8') as f:
#     f.write(wp)


#4
with open('out.txt','r',encoding='utf-8') as f:
    with open('dlyazapisi', 'w', encoding='utf-8') as f:
        for i in f:
            ps=i.split()
            nps=[]
            for p in ps:
                if p.count('/')==1:
                    a,b=p.split('/')
                    p='('+p+')'
                nps.append(p)
            f.write(' '.join(nps))


#5
