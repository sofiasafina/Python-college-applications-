# from posix import close
#
# fout=open("b.txt","w")#файл создается сам и заполняется
# A=[str(i) for i in range(7)]
# s=fout.write('*'.join(A)+"\n")#Переводим список А с помощью метода join()
# print(s)
# n=5
# m=3
# B=[[str(i) for i in range(m)] for j in range(n)]
# print(B)
# #print(b) и print(s) выводят количество символов в строке
# fout.close()
# C=[]
# fout=open("b.txt","w")
# fout.write("21083")#записываем в write сразу
# v=fout.write('21083'.join(C)+"\n")#через join
# fout.write('{:d}'+"21083")#через склеивание
# fout.close()



#задание - записать в один файл всё из другого
# fin=open("y.txt")
# fout=open("x.txt",'w')
# s1=fin.readlines()
# print(s1)
# s2=list(map(int, s1))
# mi=0;ma=s2[0]
# for i in range(len(s2)):
#     if s2[i]%2==0:
#         if s2[i]>ma:
#             ma=s2[i]
#         if s2[i]<mi:
#             mi=s2[i]
# if mi==0:
#     fout.write('таких чисел нет')
# else:
#     fout.write('максимальный элемент: '+str(ma)+"\n")
#     fout.write('минимальный элемент: '+str(mi)+"\n")
# for i in range(len(s2)):
#     fout.write(''.join(str(s2[i]))+"\n")
# fin.close()
# fout.close()



# задание сделать программу которая находит среднее арифметическое из одного и зап в другой
# fin=open("y.txt")
# fout=open("x.txt",'w',encoding="UTF-8")#система кодировки чтобы не было квадратиков
# s1=fin.read()
# # print(type(s1))
# s1=s1.split()#без split map не работаеь
# s2=list(map(int,s1))
# fout.write(str(sum(s2)/len(s2)))
# fin.close()
# fout.close()


#задание вывести в порядке возрастания все числа из одного файла в другой
# fin=open("y.txt")
# fout=open("x.txt",'w',encoding="UTF-8")#система кодировки чтобы не было квадратиков
# s1=fin.read()
# # print(type(s1))
# s1=s1.split()#без split map не работаеь
# s2=list(map(int,s1))
# sa=sorted(s2)
# for i in range(len(sa)):
#     fout.write(str[sa[i]]+"\n")
# fin.close()
# fout.close()

# # удвление элемента из файла
# fin=open("y.txt")
# s1=fin.readlines()
# fin.close()
# s2=list(map(int,s1))
# print(s2)
# fin=open("y.txt")
# s2.sort(reverse=True)
# s1=s1.split('\n')
# print(s2)
# for i in range(len(s2)):
#     if s2[i]%2!=0:
#         fin.write(str(s2[i])+"\n")
# fout.close()

# задачи с собаками
# fin=open("y.txt")
# fout=open("x.txt",'w',encoding="UTF-8")#система кодировки чтобы не было квадратиков
# s=fin.readlines()
# for i in range(len(s)):
#     u=s[i].split()
#     if int(u[i])<5:
#         fout.write(str(s[i]))