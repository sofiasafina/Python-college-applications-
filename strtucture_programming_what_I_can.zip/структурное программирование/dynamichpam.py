# #ИНВЕРСИЯ МАССИВА НЕИЗВЕСТНОЙ ДЛИНЫ
# F=open('input.txt')
# stack=[]
# while True:
#     s=F.readline()
#     if not s: break
#     stack.append(int(s))
# F.close()
# print(stack)
#
# #2 способ
# stack=[]
# for s in open('input_arr.dat'):
#     stack.append(int(s))
# print(stack)
#
# #запись в файл в обратном порядке
# F=open('output.txt','w')
# while len(stack)>0:
#     x=stack.pop()
#     F.write(str(x)+'\n')
# F.close()
# print(stack)
#
# #без прерменной х:
# F=open('output.txt','w')
# while stack:
#     F.write(str(stack.pop())+'\n')
# F.close()
# print(stack)

#ВЫЧИСЛЕНИЕ ПОСТФИКСНОЙ ФОРМЫ
data=input().split()
stack=[]
for x in data:
    print(data)
    if x in "+-/=":
        op2=int(stack.pop())
        op1=int(stack.pop())
        if x=='+': res=op1+op2
        elif x=='-': res=op1-op2
        elif x=='*': res=op1*op2
        else: res=op1//op2
        stack.append(res)
        print(data)
    else:
        stack.append(x)
        print(data)
print(stack[0])

#5 15 + 4 7 + 1 - /
#2