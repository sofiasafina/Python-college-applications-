# dic_1={'a':50,'b':40}
# dic_2={'c':5,'d':60}
# dic_3={**dic_1,**dic_2}
# print(dic_3)

# dic_1={'a':50,'b':40}
# for i in dic_1:
#     i*=i
# print(i)

# m=dict()
# for i in range(1,11):
#     m[i]=m[i]**2
# print(m)

# kays=['name','age','job']
# values=['timur','38','teacher']
# a=dict(zip(kays,values))

# counts={}
# a='programmistpy'
# for i in a:
#     if i in counts:
#         counts[i]+=1
#     else:
#         counts[i]=1
# print(counts)

