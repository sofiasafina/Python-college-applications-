from random import randint
N=5
a=[]
for i in range(N):
    a.append(randint(1,99))
print('массив а: ',a)
# for i in range(N-1):
#     for j in range(N-i-1):
#         if a[j]>a[j+1]:
#             a[j],a[j+1]=a[j+1],a[j]
#         print(a)
# print('отсортированный массив: ',a)

# a.sort(key=None,reverse=False)
# print(a)

# a.sort(key=lambda x:x%10)
# print(a)

s2="hello"
print(sorted(s2))
print(sorted(s2,reverse=True))