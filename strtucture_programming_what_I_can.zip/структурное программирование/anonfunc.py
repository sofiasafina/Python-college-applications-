# def standard_functoin(x):#стандартная функция
#     return x*2
#
# lambda_function=lambda x:x*2#анонимная функция
#
# print(standard_functoin(7))#вывод одинаковый
# print(lambda_function(7))
#
#
#
# f1=lambda: 10+20#без параметров
# f2= lambda x,y: x+y#с двумя параметрами
# f3= lambda x,y,z: x+y+z# c тремя
#
# print(f1())
# print(f2(5,10))
# print(f3(5,10,13))



# points=[(1,-1),(2,3),(-10,15),(10,9),(7,18),(1,5),(2,-4)]
#
# print(sorted(points,key=lambda point: point[1]))# сортируем по значению кортежа
# print(sorted(points, key=lambda point: point[0]+point[1]))# сотрируем по сумме элементов кортежа
# print(sorted(points, key=lambda point: point[0]))



# numbers=[1,2,3,4,5,6]
# new_numbers1 = map(lambda x : x+1, numbers)# без list() будет с адресом
# new_numbers2 = map(lambda x : x*2, numbers)
# new_numbers3 = map(lambda x : x**2, numbers)

# numbers=[1,2,3,4,5,6]
# new_numbers1 = list(map(lambda x : x+1, numbers))
# new_numbers2 = list(map(lambda x : x*2, numbers))
# new_numbers3 = list(map(lambda x : x**2, numbers))
#
# print(new_numbers1)
# print(new_numbers2)
# print(new_numbers3)



#можно использовать тернарный условный оператор

numbers = [-2,0,1,2,17,4,5,6]
result=list(map(lambda x: 'even' if x%10==2 else 'odd', numbers))
print(result)


