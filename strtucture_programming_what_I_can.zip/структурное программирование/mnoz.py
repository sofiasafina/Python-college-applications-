# a=input()
# b=set(a)
# print(len(a)==len(b))


# s=[]
# for i in range(10):
#     s.append(i)
# a=input()
# b=input()
# c=set(a.split()+b.split())
# print(c)
# s_s=set(s)
# print(len(c)==len(s_s))


# s1=input()
# s2=input()
# set1=set(s1.split())
# set2=set(s2.split())
# b=set1.union(set2)
# print(len(b))


# s1=input()
# s2=input()
# set1=set(s1.split())
# set2=set(s2.split())
# b=set1.union(set2)
# print(sorted(b))