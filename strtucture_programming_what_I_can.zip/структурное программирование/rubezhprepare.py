def chet(a):
    for i in range(7,3,-1):
        a+=1
    return a

def tech(b,c):
    while b<c:
        c+=b
    return c+b

# a=1
# b=7
# c=3
# print(chet(a),' ',tech(b,c),sep='!')
# B = [i for i in range(4) if i%2==1]
# print(B)


#2
def mass():
    for i in range(5):
        A[i]=A[i]*A[i]+1
A=[2,3,1,4,1]
print(A)
mass()
print(A)
B=[i*2 for i in A]
print(B)