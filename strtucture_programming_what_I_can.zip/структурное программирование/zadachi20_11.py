# import random
#
# f=open("out.txt","w+")
# f.write('апрель апрель апрель')
# f.close
#
# f=open("in.txt","w+")
# f.close

# 1
# f=open("out.txt",encoding="utf-8")
# c=f.read()
# print('количество символов в файле: ', len(c))


# # 2
# t=input('Введите текст ')
# with open('out.txt','w',encoding='utf-8') as f:
#     f.write(t+'\n')
#
#
# #3

# def skobki3(input_file, output_file):
#     with open(input_file, 'r', encoding='utf-8') as i:
#         text = i.read()
#     words = text.split()
#     wwords = [f'({word})' for word in words]
#     r = ' '.join(w_words)
#     with open(output_file, 'w', encoding='utf-8') as outfile:
#         outfile.write(r_text)
#
#
# inputt = 'in.txt'
# outputt = 'out.txt'
# skobki3(inputt, outputt)

#
#
# #4

# def skobki4(input_file, output_file):
#     with open(input_file, 'r', encoding='utf-8') as i:
#         text = i.read()
#     words = text.split()
#     wwords = [f'({word})' if '/' in word]
#     r_text = ' '.join(wwords)
#     with open(output_file, 'w', encoding='utf-8') as outfile:
#         outfile.write(r_text)
#
# inputt = 'in.txt'
# outputt = 'out.txt'
# skobki4(inputt, outputt)
#
#
# # уровень 2
#1


# def peremeshat(input_file, output_file):
#     with open(input_file, 'r', encoding='utf-8') as i:
#         text = i.read()
#     sentences = text.split('. ')
#     shuffled_sentences = []
#     for sentence in sentences:
#         words = sentence.split()
#         random.shuffle(words)
#         shuffled_sentences.append(' '.join(words))
#     r_text = '. '.join(shuffled_sentences)
#     with open(output_file, 'w', encoding='utf-8') as outfile:
#         outfile.write(r_text)
#
#
# inputt = 'in.txt'
# outputt = 'out.txt'
# peremeshat(inputt, outputt)


# #2
# r=""
# for i in range(1,4):
#     for j in range(1,4):
#         r+=str(i)+str(j)+" "
# print(r)


# #3
# def otsort(s):
#     return sorted(s,key=sum)
# A=[
#     [2,4,5],
#     [1,2,3],
#     [0,1,1],
#     [5,7,1],
# ]
#
# print(otsort(A))


# #4
def slut(s):
    r=[]
    for i in s:
        r.append(int(''.join(map(str,i))))
    return r

A=[
    [2,4,5],
    [1,2,3],
    [2,1,1],
    [5,7,1],
]

print(slut(A))