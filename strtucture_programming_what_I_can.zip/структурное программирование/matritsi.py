from random import randint


def printMatrix(A):
    for row in A:
        for x in row:
            print("{:0.2f}".format(x),end="")
        print()


#основная программа
A=[]
N=3
M=3
for i in range(N):
    A.append([0]*M)

# for i in range(5):
#     print(printMatrix(A))

for i in range(N):
    for j in range(N):
        for i in range(M):
            A[i][j]=randint(20,80)
            print("{:4d}".format(A[i][j]),end="")
        print()

