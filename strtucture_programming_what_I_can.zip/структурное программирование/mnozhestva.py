A=[1,2,7,5,6,8]
B=[3,6,6,6,6,6]
# print("количестыво неповт: ",len(set(A))+len(set(B)))
# print(max(set(A)))
# print(min(set(A)))
# print(set(A)&set(B))
# for i in A:
#     print(i)
print('1' in set(B))

