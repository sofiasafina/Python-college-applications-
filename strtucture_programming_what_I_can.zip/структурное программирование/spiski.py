# s=input().split()
# A=list(map(int,s))
# print(*A)

# N=5
# A=[0]*N
# for i in range(N):
#     print("A[",i,"]=",sep="",end="")
#     A[i]=int(input())#имя преременной в списке

# from random import randint
# N=10
# A=[randint(20,100) for x in range (N)]

# count=0
# summ=0
# for x in A:
#     if 180<x<190:
#         count+=1
#         summ+=x
# print(summ/count)

# N=int(input("Введите число "))
# summa=0
# k=0
# while N!=0:
#     digit=N%10
#     summa+=digit
#     k+=1
#     print(summa)
#     N//=10
# print('Среднее арифметическое: ',summa/k)

