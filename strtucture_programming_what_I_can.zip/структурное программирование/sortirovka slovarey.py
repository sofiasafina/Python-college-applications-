# capitals={'Россия':'Москва','Англия':'Лондон','Чехия':'Прага'}
# for key,value in sorted(capitals.items(),key=lambda x:x[1]):
#     print(value)

# slov=[]
# slovar={'один':1,'два':2,'три':3}
# # for key,value in sorted(slovar.items(),key=lambda x:x[1]):
# #     print(value)
# #     slov.append(value)#чтобы сохранить отсортированный словарь
# # print(slov)

# slovar2={1:3,2:3,3:3,4:3}
# print(slovar.update(slovar2))#Метод update

lst=[10,3,1,3,7,3,1,7,1,7,9]
rez={}
for i in lst:
    if rez.get(i,None):
        rez[i]+=1
    else:
        rez[i]=1
print(rez)
rez_sorted=sorted(rez.items(),key=lambda x: -x[1])
print(rez_sorted)#Так хранится в памяти компьютера
print(dict(rez_sorted))