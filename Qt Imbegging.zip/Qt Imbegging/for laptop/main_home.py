# -*- coding: utf-8 -*-
import sys
import re
import os
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtCore import QSize

from avt import Ui_Widget as AvtUI
from glav import Ui_Widget as GlavUI
from regi import Ui_Widget as RegiUI

# ============================================
# ЭМУЛЯТОР БАЗЫ ДАННЫХ
# ============================================

USERS = {
    'admin': '123456',
    'test': '123456',
    'user': '123456'
}


def register_user(login, password):
    if not re.match(r'^[a-zA-Z]+$', login):
        return False, "Логин должен содержать только латинские буквы"
    if not re.match(r'^[a-zA-Z0-9]{6,}$', password):
        return False, "Пароль должен содержать от 6 символов"
    if login in USERS:
        return False, "Пользователь с таким логином уже существует"
    USERS[login] = password
    return True, "Регистрация успешна!"


def auth_user(login, password):
    if login in USERS and USERS[login] == password:
        return True, "Авторизация успешна!"
    return False, "Неверный логин или пароль"


# ============================================
# ГЛАВНОЕ ОКНО
# ============================================

class GlavWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = GlavUI()
        self.ui.setupUi(self)
        self.setWindowTitle("Главное меню")

        self.ui.pushButton.clicked.connect(self.open_auth)
        self.ui.pushButton_2.clicked.connect(self.open_reg)
        self.ui.pushButton_3.clicked.connect(self.close)

    def open_auth(self):
        self.auth_window = AuthWindow()
        self.auth_window.show()
        self.hide()

    def open_reg(self):
        self.reg_window = RegWindow()
        self.reg_window.show()
        self.hide()


# ============================================
# ОКНО АВТОРИЗАЦИИ
# ============================================

class AuthWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = AvtUI()
        self.ui.setupUi(self)
        self.setWindowTitle("Авторизация")

        self.ui.pushButton.clicked.connect(self.login)
        self.ui.pushButton_2.clicked.connect(self.back)

    def login(self):
        login = self.ui.lineEdit_2.text().strip()
        password = self.ui.lineEdit.text().strip()

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль")
            return

        success, message = auth_user(login, password)
        if success:
            QMessageBox.information(self, "Успех", f"Добро пожаловать, {login}!")
            self.cards_window = CardsWindow(login)
            self.cards_window.show()
            self.close()
        else:
            QMessageBox.warning(self, "Ошибка", message)

    def back(self):
        self.close()
        self.glav = GlavWindow()
        self.glav.show()


# ============================================
# ОКНО РЕГИСТРАЦИИ
# ============================================

class RegWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = RegiUI()
        self.ui.setupUi(self)
        self.setWindowTitle("Регистрация")

        self.ui.pushButton.clicked.connect(self.register)
        self.ui.pushButton_2.clicked.connect(self.back)

    def register(self):
        login = self.ui.lineEdit_2.text().strip()
        password = self.ui.lineEdit.text().strip()

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все поля")
            return

        success, message = register_user(login, password)
        if success:
            QMessageBox.information(self, "Успех", message)
            self.cards_window = CardsWindow(login)
            self.cards_window.show()
            self.close()
        else:
            QMessageBox.warning(self, "Ошибка", message)

    def back(self):
        self.close()
        self.glav = GlavWindow()
        self.glav.show()


# ============================================
# ОКНО КАРТОЧЕК
# ============================================

class CardsWindow(QWidget):
    def __init__(self, login):
        super().__init__()
        self.login = login
        self.setWindowTitle(f"Карточки товаров - {login}")
        self.setGeometry(100, 100, 900, 700)

        # Список
        self.list_widget = QListWidget()

        # Поиск
        self.search_field = QLineEdit()
        self.search_field.setPlaceholderText("Поиск товаров...")

        # Кнопки
        self.back_button = QPushButton("◀ Назад в главное меню")
        self.table_button = QPushButton("📊 Моя таблица")
        self.close_button = QPushButton("❌ Закрыть")

        # Скролл
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidget(self.list_widget)
        self.scroll_area.setWidgetResizable(True)

        # Layout
        layout = QVBoxLayout()
        layout.addWidget(self.scroll_area)
        layout.addWidget(self.search_field)

        button_layout = QHBoxLayout()
        button_layout.addWidget(self.back_button)
        button_layout.addWidget(self.table_button)
        button_layout.addWidget(self.close_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

        # Сигналы
        self.search_field.textChanged.connect(self.filter_items)
        self.back_button.clicked.connect(self.back_to_glav)
        self.table_button.clicked.connect(self.open_table)
        self.close_button.clicked.connect(self.close)

        # Данные
        self.create_products()
        self.create_card()

    def create_products(self):
        self.products = [
            ("Ноутбук Lenovo", "Мощный ноутбук для работы", "images/lenovo.png"),
            ("Смартфон iPhone", "Новейший iPhone", "images/iphone.png"),
            ("Наушники Sony", "Беспроводные наушники", "images/sony.png"),
            ("Мышь Logitech", "Игровая мышь", "images/logitech.png"),
            ("Клавиатура", "Механическая клавиатура", "images/keyboard.png"),
            ("Монитор Samsung", "4K монитор", "images/samsung.png"),
            ("Внешний диск", "1TB SSD", "images/ssd.png"),
            ("Веб-камера", "4K веб-камера", "images/camera.png"),
            ("Планшет iPad", "10 дюймов", "images/ipad.png"),
            ("Принтер HP", "Лазерный принтер", "images/printer.png"),
        ]

    def create_card(self):
        for name, desc, img_path in self.products:
            if os.path.exists(img_path):
                pixmap = QPixmap(img_path)
                icon = QIcon(pixmap) if not pixmap.isNull() else QIcon()
            else:
                icon = QIcon()

            item = QListWidgetItem(icon, f"{name}\n{desc}")
            self.list_widget.addItem(item)

        self.list_widget.setIconSize(QSize(80, 80))
        self.list_widget.setResizeMode(QListWidget.Adjust)

    def filter_items(self, text):
        search_text = text.lower().strip()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            item_text = item.text().lower()
            item.setHidden(search_text not in item_text and search_text != "")

    def open_table(self):
        """Открыть таблицу"""
        self.table_window = TableWindow(self.login)
        self.table_window.show()

    def back_to_glav(self):
        """Назад в главное меню"""
        self.close()
        self.glav = GlavWindow()
        self.glav.show()


# ============================================
# ОКНО ТАБЛИЦЫ
# ============================================

class TableWindow(QWidget):
    def __init__(self, login):
        super().__init__()
        self.login = login
        self.setWindowTitle(f"Мои данные - {login}")
        self.setGeometry(150, 150, 800, 500)

        # Таблица
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Название", "Значение"])
        self.table.horizontalHeader().setStretchLastSection(True)

        # Кнопки
        self.add_btn = QPushButton("➕ Добавить")
        self.delete_btn = QPushButton("🗑 Удалить")
        self.back_btn = QPushButton("◀ Назад к карточкам")

        # Layout
        layout = QVBoxLayout()
        layout.addWidget(self.table)

        button_layout = QHBoxLayout()
        button_layout.addWidget(self.add_btn)
        button_layout.addWidget(self.delete_btn)
        button_layout.addWidget(self.back_btn)

        layout.addLayout(button_layout)
        self.setLayout(layout)

        # Сигналы
        self.add_btn.clicked.connect(self.add_row)
        self.delete_btn.clicked.connect(self.delete_row)
        self.back_btn.clicked.connect(self.back_to_cards)

        # Данные
        self.load_data()

    def load_data(self):
        fake_data = {
            'admin': [
                ('Имя', 'Администратор'),
                ('Возраст', '25'),
                ('Город', 'Москва')
            ],
            'test': [
                ('Имя', 'Тестовый пользователь'),
                ('Возраст', '30'),
                ('Город', 'Санкт-Петербург')
            ],
            'user': [
                ('Имя', 'Обычный пользователь'),
                ('Возраст', '20'),
                ('Город', 'Казань')
            ]
        }

        data = fake_data.get(self.login, [('Нет данных', 'Нажмите "Добавить"')])

        self.table.setRowCount(len(data))
        for i, (name, value) in enumerate(data):
            self.table.setItem(i, 0, QTableWidgetItem(name))
            self.table.setItem(i, 1, QTableWidgetItem(value))

        self.table.resizeColumnsToContents()

    def add_row(self):
        name, ok1 = QInputDialog.getText(self, "Добавить", "Название:")
        if not ok1 or not name.strip():
            return
        value, ok2 = QInputDialog.getText(self, "Добавить", "Значение:")
        if not ok2 or not value.strip():
            return

        row = self.table.rowCount()
        if row == 1 and self.table.item(0, 0).text() == "Нет данных":
            self.table.setRowCount(0)
            row = 0

        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(name.strip()))
        self.table.setItem(row, 1, QTableWidgetItem(value.strip()))
        self.table.resizeColumnsToContents()

    def delete_row(self):
        row = self.table.currentRow()
        if row >= 0:
            if self.table.item(row, 0).text() == "Нет данных":
                return
            self.table.removeRow(row)
            if self.table.rowCount() == 0:
                self.table.setRowCount(1)
                self.table.setItem(0, 0, QTableWidgetItem("Нет данных"))
                self.table.setItem(0, 1, QTableWidgetItem("Нажмите 'Добавить'"))

    def back_to_cards(self):
        self.close()
        self.cards = CardsWindow(self.login)
        self.cards.show()


# ============================================
# ЗАПУСК
# ============================================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GlavWindow()
    window.show()
    sys.exit(app.exec_())