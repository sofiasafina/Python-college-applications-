# -*- coding: utf-8 -*-
# Эмулятор БД для работы дома (без MySQL)

# Хранилище пользователей в памяти
USERS = {
    'admin': '123456',
    'test': '123456',
    'user': '123456'
}

def get_connection():
    """Эмуляция подключения"""
    return "fake_connection"

def register_user(login, password):
    """Эмуляция регистрации"""
    import re
    if not re.match(r'^[a-zA-Z]+$', login):
        return False, "Логин должен содержать только латинские буквы"
    if not re.match(r'^[a-zA-Z0-9]{6,}$', password):
        return False, "Пароль должен содержать от 6 символов"
    if login in USERS:
        return False, "Пользователь с таким логином уже существует"
    USERS[login] = password
    return True, "Регистрация успешна!"

def auth_user(login, password):
    """Эмуляция авторизации"""
    if login in USERS and USERS[login] == password:
        return True, "Авторизация успешна!"
    return False, "Неверный логин или пароль"