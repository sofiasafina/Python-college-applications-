# -*- coding: utf-8 -*-
import sys
import re
import mysql.connector
from PyQt5.QtWidgets import QApplication, QWidget, QMessageBox
from PyQt5.QtCore import Qt

# Импортируем UI классы
from avt import Ui_Widget as AvtUI
from glav import Ui_Widget as GlavUI
from regi import Ui_Widget as RegiUI
from cards import CardsWindow


# ============================================
# ФУНКЦИИ ДЛЯ РАБОТЫ С БД
# ============================================

def get_connection():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            database='horizon',
            user='root',
            port=3306,
            password=''  # если есть пароль - укажите
        )
        return conn
    except mysql.connector.Error as e:
        print(f"Ошибка подключения к БД: {e}")
        return None
    except Exception as e:
        print(f"Другая ошибка: {e}")
        return None


def register_user(login, password):
    # Проверка логина (только латинские буквы)
    if not re.match(r'^[a-zA-Z]+$', login):
        return False, "Логин должен содержать только латинские буквы"

    # Проверка пароля (от 6 символов, латиница и цифры)
    if not re.match(r'^[a-zA-Z0-9]{6,}$', password):
        return False, "Пароль должен содержать от 6 символов (латинские буквы и цифры)"

    conn = get_connection()
    if not conn:
        return False, "Ошибка подключения к БД. Убедитесь, что MySQL запущен."

    try:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM guys WHERE login = %s', (login,))
        if cursor.fetchone():
            cursor.close()
            conn.close()
            return False, "Пользователь с таким логином уже существует"

        cursor.execute('INSERT INTO guys (login, parol) VALUES (%s, %s)', (login, password))
        conn.commit()
        cursor.close()
        conn.close()
        return True, "Регистрация успешна!"
    except mysql.connector.Error as e:
        return False, f"Ошибка БД: {e}"
    except Exception as e:
        return False, f"Ошибка: {e}"


def auth_user(login, password):
    conn = get_connection()
    if not conn:
        return False, "Ошибка подключения к БД. Убедитесь, что MySQL запущен."

    try:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM guys WHERE login = %s AND parol = %s', (login, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        if user:
            return True, "Авторизация успешна!"
        else:
            return False, "Неверный логин или пароль"
    except mysql.connector.Error as e:
        return False, f"Ошибка БД: {e}"
    except Exception as e:
        return False, f"Ошибка: {e}"


# ============================================
# ГЛАВНОЕ ОКНО
# ============================================

class GlavWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = GlavUI()
        self.ui.setupUi(self)
        self.setWindowTitle("Главное меню")

        self.ui.pushButton.clicked.connect(self.open_auth)
        self.ui.pushButton_2.clicked.connect(self.open_reg)
        self.ui.pushButton_3.clicked.connect(self.close)

    def open_auth(self):
        self.auth_window = AuthWindow()
        self.auth_window.show()
        self.hide()

    def open_reg(self):
        self.reg_window = RegWindow()
        self.reg_window.show()
        self.hide()


# ============================================
# ОКНО АВТОРИЗАЦИИ
# ============================================

class AuthWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = AvtUI()
        self.ui.setupUi(self)
        self.setWindowTitle("Авторизация")

        self.ui.pushButton.clicked.connect(self.login)
        self.ui.pushButton_2.clicked.connect(self.back_to_glav)

    def login(self):
        login = self.ui.lineEdit_2.text().strip()
        password = self.ui.lineEdit.text().strip()

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль")
            return

        success, message = auth_user(login, password)
        if success:
            QMessageBox.information(self, "Успех", f"Добро пожаловать, {login}!")
            self.cards_window = CardsWindow(login)
            self.cards_window.show()
            self.close()
        else:
            QMessageBox.warning(self, "Ошибка", message)

    def back_to_glav(self):
        self.close()
        self.glav_window = GlavWindow()
        self.glav_window.show()


# ============================================
# ОКНО РЕГИСТРАЦИИ
# ============================================

class RegWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = RegiUI()
        self.ui.setupUi(self)
        self.setWindowTitle("Регистрация")

        self.ui.pushButton.clicked.connect(self.register)
        self.ui.pushButton_2.clicked.connect(self.back_to_glav)

    def register(self):
        login = self.ui.lineEdit_2.text().strip()
        password = self.ui.lineEdit.text().strip()

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все поля")
            return

        success, message = register_user(login, password)
        if success:
            QMessageBox.information(self, "Успех", message)
            self.cards_window = CardsWindow(login)
            self.cards_window.show()
            self.close()
        else:
            QMessageBox.warning(self, "Ошибка", message)

    def back_to_glav(self):
        self.close()
        self.glav_window = GlavWindow()
        self.glav_window.show()


# ============================================
# ЗАПУСК
# ============================================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GlavWindow()
    window.show()
    sys.exit(app.exec_())