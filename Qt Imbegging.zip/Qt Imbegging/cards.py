# -*- coding: utf-8 -*-
import sys
import os
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtCore import QSize


class CardsWindow(QWidget):
    def __init__(self, login, parent=None):
        super().__init__(parent)
        self.login = login
        self.parent_window = parent
        self.setWindowTitle(f"Карточки товаров - {login}")
        self.setGeometry(100, 100, 900, 700)

        self.list_widget = QListWidget()
        self.search_field = QLineEdit()
        self.search_field.setPlaceholderText("Поиск товаров...")

        self.back_button = QPushButton("◀ Назад в главное меню")
        self.table_button = QPushButton("📊 Моя таблица")
        self.close_button = QPushButton("❌ Закрыть")

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidget(self.list_widget)
        self.scroll_area.setWidgetResizable(True)

        layout = QVBoxLayout()
        layout.addWidget(self.scroll_area)
        layout.addWidget(self.search_field)

        button_layout = QHBoxLayout()
        button_layout.addWidget(self.back_button)
        button_layout.addWidget(self.table_button)
        button_layout.addWidget(self.close_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

        self.search_field.textChanged.connect(self.filter_items)
        self.back_button.clicked.connect(self.back_to_glav)
        self.table_button.clicked.connect(self.open_table)
        self.close_button.clicked.connect(self.close)

        self.create_products()
        self.create_card()

    def create_products(self):
        self.products = [
            ("Ноутбук Lenovo", "Мощный ноутбук для работы", "images/lenovo.png"),
            ("Смартфон iPhone", "Новейший iPhone", "images/iphone.png"),
            ("Наушники Sony", "Беспроводные наушники", "images/sony.png"),
            ("Мышь Logitech", "Игровая мышь", "images/logitech.png"),
            ("Клавиатура", "Механическая клавиатура", "images/keyboard.png"),
            ("Монитор Samsung", "4K монитор", "images/samsung.png"),
            ("Внешний диск", "1TB SSD", "images/ssd.png"),
            ("Веб-камера", "4K веб-камера", "images/camera.png"),
            ("Планшет iPad", "10 дюймов", "images/ipad.png"),
            ("Принтер HP", "Лазерный принтер", "images/printer.png"),
        ]

    def create_card(self):
        for name, desc, img_path in self.products:
            if os.path.exists(img_path):
                pixmap = QPixmap(img_path)
                if not pixmap.isNull():
                    icon = QIcon(pixmap)
                else:
                    icon = QIcon()
            else:
                icon = QIcon()

            item = QListWidgetItem(icon, f"{name}\n{desc}")
            self.list_widget.addItem(item)

        self.list_widget.setIconSize(QSize(80, 80))
        self.list_widget.setResizeMode(QListWidget.Adjust)

    def filter_items(self, text):
        search_text = text.lower().strip()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            item_text = item.text().lower()
            item.setHidden(search_text not in item_text and search_text != "")

    def open_table(self):
        from table_window import TableWindow
        self.table_window = TableWindow(self.login, self)
        self.table_window.show()

    def back_to_glav(self):
        """Возврат в главное меню - ПРОСТО ЗАКРЫВАЕМ ОКНО КАРТОЧЕК"""
        self.close()  # Закрываем карточки
        # Главное окно ВСЕГДА видно, потому что мы его НЕ ПРЯТАЛИ!


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CardsWindow("guest")
    window.show()
    sys.exit(app.exec_())