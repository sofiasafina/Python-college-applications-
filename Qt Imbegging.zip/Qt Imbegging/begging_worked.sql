CREATE DATABASE IF NOT EXISTS horizon;
USE horizon;
CREATE TABLE guys (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    login VARCHAR(50) UNIQUE, 
    parol VARCHAR(255)
);
INSERT INTO guys (login, parol) VALUES ('admin', '123456');
INSERT INTO guys (login, parol) VALUES ('test', '123456');